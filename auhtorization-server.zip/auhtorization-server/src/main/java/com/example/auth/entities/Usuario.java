package com.example.auth.entities;

import java.util.Set;

import org.hibernate.annotations.ManyToAny;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.Table;
import jakarta.persistence.JoinColumn;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name = "USUARIOS_OAUTH")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class Usuario {
	
	 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "ID_USUARIO")
	    private Long id;

	    @Column(name = "USERNAME", nullable = false, length = 20, unique = true)
	    @NotBlank(message = "El username es requerido")
	    @Size(min = 4, max = 20, message = "El username debe tener entre 4 y 20 caracteres")
	    private String username;

	    @Column(name = "PASSWORD", nullable = false)
	    @NotBlank(message = "La contraseña es requerida")
	    @Size(min = 8, message = "La contraseña debe tener entre 8 y 20 caracteres")
	    private String password;

	    @ManyToAny(fetch = FetchType.EAGER)
	    @JoinTable(
	            name = "USUARIOS_ROLES",
	            joinColumns = @JoinColumn(name = "ID_USUARIO"),
	            inverseJoinColumns = @JoinColumn(name = "ID_ROL")
	    )
	    @NotNull(message = "Los roles son requeridos")
	    @Size(min = 1, message = "El usuario debe tener al menos 1 rol")
	    private Set<Rol> roles;



}
